export class Console {
	log(message) {
		println(message);
	}
}

//export { Console as ConsoleTest };
