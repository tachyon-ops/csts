import { Console } from "./import/Console";

export class Console {
	log(message) {
		println(message);
	}
}
var console = new Console();
console.log("test");
println("test");